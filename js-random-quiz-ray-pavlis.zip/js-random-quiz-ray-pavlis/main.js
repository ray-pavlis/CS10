// Boxes Quiz

// Event Listener
document.getElementById('mark-btn').addEventListener('click', markQuiz);


// Event Function
function markQuiz() {
    // Variables
    let score = 0
    let qOne = document.getElementById('question-one').value;
    
    if (qOne == 2 || qOne == 3) {
        document.getElementById('qOne-feedback').innerHTML = 'Question one is correct.'

        score++
    } else {
        document.getElementById('qOne-feedback').innerHTML = 'Question one is incorrect.'
    }
    let qTwo = document.getElementById('question-two').value;

    if (qTwo == 2) {
        document.getElementById('qTwo-feedback').innerHTML = 'Question two is correct.'

        score++
    } else {
        document.getElementById('qTwo-feedback').innerHTML = 'Question two is incorrect.'
    }

    let qThree = document.getElementById('question-three').value;

    if (qThree == 4) {
        document.getElementById('qThree-feedback').innerHTML = 'Question three is correct.'

        score++
    } else {
        document.getElementById('qThree-feedback').innerHTML = 'Question three is incorrect.'
    }

    let qFour = document.getElementById('question-four').value;

    if (qFour == 1) {
        document.getElementById('qFour-feedback').innerHTML = 'Question four is correct.'

        score++
    } else {
        document.getElementById('qFour-feedback').innerHTML = 'Question four is incorrect.'
    }
    
    document.getElementById('results').innerHTML = 'Your score is ' + score + '/4.'

    if (score == 4) {
        document.getElementById('percent').innerHTML = "Good job! 100%"

    } else if (score == 3) {
        document.getElementById('percent').innerHTML = "You did okay. 75%"

    } else if (score == 2) {
        document.getElementById('percent').innerHTML = "You got half of it right. 50%"

    } else if (score == 1) {
        document.getElementById('percent').innerHTML = "Not so great... 25%"

    } else {
        document.getElementById('percent').innerHTML = "Wow, you need help. Here's a tip! Pick the weirdest answers. 0%"
    }
}