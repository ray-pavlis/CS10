// Minecraft Fishing Sim
'use strict';

// Global Variables
let numFish = 0;
let numJunk = 0;
let numTreasure = 0;

let resultsEl = document.getElementById('results')

// Event Listeners
document.getElementById('mainImg').addEventListener('click', catchFish);

// Event Fuctions
function catchFish() {
    // Generate a Random Number
    let randNum = Math.random(); // Random decimal from 0 up to 1

    // Simulate results
    if (randNum < 0.85) {
        // Catch Fish - Simulate What Type of Fish to Catch
        let randFish = Math.random();
        if (randFish < 0.5) {
            // Raw Fish
            console.log('raw fish');
            
            numFish++;
            document.getElementById('fish').innerHTML = numFish;
            resultsEl.innerHTML += '<img src="images/RawFish.png">'

        } else if (randFish < 0.7) {
            // Raw Salmon
            console.log('raw salmon');
            
            numFish++;
            document.getElementById('fish').innerHTML = numFish;
            resultsEl.innerHTML += '<img src="images/Raw_Salmon.png">'
        } else if (randFish < 0.9) {
            // Pufferfish
            console.log('pufferfish');
            
            numFish++;
            document.getElementById('fish').innerHTML = numFish;
            resultsEl.innerHTML += '<img src="images/Pufferfish.png">'
        } else {
            // Clownfish
            console.log('clownfish');
            
            numFish++;
            document.getElementById('fish').innerHTML = numFish;
            resultsEl.innerHTML += '<img src="images/Clownfish.png">'
        }

    } else if (randNum < 0.95) {
        // Catch Junk
        console.log('junk');
        numJunk++;
        document.getElementById('junk').innerHTML = numJunk;
        resultsEl.innerHTML += '<img src="images/leatherboots.png">'

    } else {
        // Catch Treasure
        console.log('treasure');
        numTreasure++;
        document.getElementById('treasure').innerHTML = numTreasure;
        resultsEl.innerHTML += '<img src="images/Bow.png">'

    }
}