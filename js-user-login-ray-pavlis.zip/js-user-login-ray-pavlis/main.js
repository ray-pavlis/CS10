//Company Login

// Event Listener
document.getElementById('login-btn').addEventListener('click', login);

// Event Function
function login() {
    // Get Input Value
    let username = document.getElementById('username').value;
    let password = document.getElementById('password').value;

    // Test Input Variable (update the page)
    if (username == 'r.pavlis' && password == 'Password123') {
            // Update page to successful
            document.getElementById('message').innerHTML = 'LOGIN SUCCESSFUL.';
    } else if (username != 'r.pavlis' && password == 'Password123') {
             // Update page to incorrect username
             document.getElementById('message').innerHTML = 'USERNAME INCORRECT. Please retry.';
    } else if (username == 'r.pavlis' && password != 'Password123') {
            // Update page to incorrect password
            document.getElementById('message').innerHTML = 'PASSWORD INCORRECT. Please retry.';
    } else {
            // Update page to unsuccessful
            document.getElementById('message').innerHTML = 'LOGIN UNSUCCESSFUL. Please retry.';
    }
}