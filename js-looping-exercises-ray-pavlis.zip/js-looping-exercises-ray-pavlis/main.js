// Looping Exercises

// Event Listeners
document.getElementById('start').addEventListener('click', startCode)

// Output elements
let happy = document.getElementById('happy');
let four = document.getElementById('multi4');
let odds = document.getElementById('odds');
let sum1 = document.getElementById('sum1');
let sum2 = document.getElementById('sum2');

alert("Please check the console after pressing start!");

function startCode() {
    // Loop 1
    for (let n = 0; n < 500; n++) {
        console.log("I'm so happy!");
        happy.innerHTML += ":) ";
    }

    // Loop 2
    for (let multi4 = 12; multi4 <= 800; multi4 += 4) {
        console.log(multi4);
        four.innerHTML += multi4 + ' ';
    }

    // Loop 3
    for (let oddNum = 55; oddNum >= 11; oddNum -= 2) {
        console.log(oddNum);
        odds.innerHTML += oddNum + ' ';
    }

    // Loop 4
    let fullSum1 = 0;
    for (let n = 5; n <= 50; n++) {
        fullSum1 += n;
    }
    console.log('The sum is: ' + fullSum1);
    sum1.innerHTML += 'The sum is: ' + fullSum1;

    // Loop 5
    let fullSum2 = 0;
    for (let n = 10; n <= 100; n += 10) {
        fullSum2 += n;
    }
    console.log('The sum is: ' + fullSum2);
    sum2.innerHTML += 'The sum is: ' + fullSum2;
}