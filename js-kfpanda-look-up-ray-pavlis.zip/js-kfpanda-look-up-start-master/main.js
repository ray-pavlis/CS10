// Kung Fu Panda Look Up

// Event Listener
document.getElementById('search').addEventListener('click', characterSearch);

// Event Function
function characterSearch() {
    // Get Input Value (what character to look for)
    let name = document.getElementById('input-name').value;
    nme = name.toLowerCase();

    // Test Input Variable (update the page)
    if (name == 'tigress' || name == 'master tigress') {
        // Update page to Tigress
        document.getElementById('main-img').src = 'images/tigress.png';
        document.getElementById('character-name').innerHTML = 'Tigress';
        document.getElementById('quote').innerHTML = '"That was pretty hardcore!"'
        document.getElementById('wiki-link').innerHTML = 'Tigress Wiki'
        document.getElementById('wiki-link').href = 'https://kungfupanda.fandom.com/wiki/Tigress'

    } else  if (name == 'crane' || name == 'master crane') {
        // Update page to Crane
        document.getElementById('main-img').src = 'images/crane.png';
        document.getElementById('character-name').innerHTML = 'Crane';
        document.getElementById('quote').innerHTML = '"	You can chain my body, but you will never chain my warrior spirit!"'
        document.getElementById('wiki-link').innerHTML = 'Crane Wiki'
        document.getElementById('wiki-link').href = 'https://kungfupanda.fandom.com/wiki/Crane'

    } else  if (name == 'mantis' || name == 'master mantis') {
        // Update page to Mantis
        document.getElementById('main-img').src = 'images/mantis.png';
        document.getElementById('character-name').innerHTML = 'Mantis';
        document.getElementById('quote').innerHTML = '"Fear the bug!"'
        document.getElementById('wiki-link').innerHTML = 'Mantis Wiki'
        document.getElementById('wiki-link').href = 'https://kungfupanda.fandom.com/wiki/Mantis'

    } else  if (name == 'viper' || name == 'master viper') {
        // Update page to Viper
        document.getElementById('main-img').src = 'images/viper.png';
        document.getElementById('character-name').innerHTML = 'Viper';
        document.getElementById('quote').innerHTML = '"I dont need to bite to fight!"'
        document.getElementById('wiki-link').innerHTML = 'Viper Wiki'
        document.getElementById('wiki-link').href = 'https://kungfupanda.fandom.com/wiki/Viper'

    } else  if (name == 'monkey' || name == 'master monkey') {
        // Update page to Monkey
        document.getElementById('main-img').src = 'images/monkey.png';
        document.getElementById('character-name').innerHTML = 'Monkey';
        document.getElementById('quote').innerHTML = '"We should hang out."'
        document.getElementById('wiki-link').innerHTML = 'Monkey Wiki'
        document.getElementById('wiki-link').href = 'https://kungfupanda.fandom.com/wiki/Monkey'

    } else if (name == 'po' || name == 'master po' || name == 'dragon warrior') {
        // Update page to Po
        document.getElementById('main-img').src = 'images/po.png';
        document.getElementById('character-name').innerHTML = 'Po';
        document.getElementById('quote').innerHTML = '"Buddy, I am the Dragon Warrior."'
        document.getElementById('wiki-link').innerHTML = 'Po Wiki'
        document.getElementById('wiki-link').href = 'https://kungfupanda.fandom.com/wiki/Po'

    } else {
        // Update page to Question Mark
        document.getElementById('main-img').src = 'images/question-mark.png';
        document.getElementById('character-name').innerHTML = '?????';
        document.getElementById('quote').innerHTML = 'Character Not Found'
        document.getElementById('wiki-link').innerHTML = 'Wiki Home'
        document.getElementById('wiki-link').href = 'https://kungfupanda.fandom.com/wiki/Kung_Fu_Panda_Wiki'
    }
}