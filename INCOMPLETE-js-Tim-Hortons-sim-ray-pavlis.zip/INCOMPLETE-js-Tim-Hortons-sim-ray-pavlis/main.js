// Timmies Roll Up the Rim Simulator
'use strict';

// Global Variables
let numPpa = 0;
let numCoffee = 0;
let numDonut = 0;
let numGrand = 0;

// Event Listeners
document.getElementById('provinceBtn').addEventListener('click', enterBtn);
document.getElementById('run1').addEventListener('click', runOne);
document.getElementById('run5').addEventListener('click', runTen);
document.getElementById('runUntilGrand').addEventListener('click', runGrand);
document.getElementById('runUntil500').addEventListener('click', run500);

// Event Functions
function enterBtn() {
    let area = document.getElementById('province').value;
}

// Simulate Rolling Up Rim
function runOne() {
    let randNum = Math.random();
    // BC Chances
    if (area == 'British Columbia') {
        if (randNum < 0.70) {
            numPpa++;
            document.getElementById('ppa').innerHTML = numPpa;

        } else if (randNum < 0.80) {
            numCoffee++;
            document.getElementById('coffee').innerHTML = numCoffee;
        } else if (randNum < 0.90) {
            numDonut++;
            document.getElementById('donut').innerHTML = numDonut;

        } else {
            numGrand++;
            document.getElementById('grandPrize').innerHTML = numGrand;

        }
    // } else if (province == 'Alberta') {

    // } else if (province == 'Saskatchewan') {

    } else {
        console.log('error')
    }
}

function runTen() {
    for (let n = 0; n < 10; n++) {
        runOne();
    }
}

function runGrand() {
    while (numGrand < 1) {
        runOne();
    }
}

function run500() {
    while (numDonut < 500) {
        runOne();
    }
}