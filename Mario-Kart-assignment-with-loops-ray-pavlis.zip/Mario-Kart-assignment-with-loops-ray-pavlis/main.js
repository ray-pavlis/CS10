// Mario Kart Item Box Sim
'use strict';

// Global Variables
let numBan = 0;
let numShell = 0;
let numStar = 0;
let numMush = 0;
let numBill = 0;

let resultsEl = document.getElementById('results');

// Event Listeners
document.getElementById('mainImg').addEventListener('click', getItem);
document.getElementById('run5').addEventListener('click', runFive);
document.getElementById('until5bills').addEventListener('click', fiveBills);
document.getElementById('until10bills').addEventListener('click', tenBills);

// Event Functions
function getItem() {
    // Generate Number
    let randNum = Math.random();

    // Simulate Results
    if (randNum < 0.25) {
        // Get Banana
        numBan++;
        document.getElementById('banana').innerHTML = numBan;
        resultsEl.innerHTML += '<img src="images/banana.jpeg">'
        console.log('banana');

    } else if (randNum < 0.50) {
        // Get Green Shell
        numShell++;
        document.getElementById('shell').innerHTML = numShell;
        resultsEl.innerHTML += '<img src="images/greenshell.jpeg">'
        console.log('green shell');

    } else if (randNum < 0.65) {
        //Get Star
        numStar++;
        document.getElementById('star').innerHTML = numStar;
        resultsEl.innerHTML += '<img src="images/star.png">'
        console.log('star');

    } else if (randNum < 0.80) {
        // Get Golden Mushroom
        numMush++;
        document.getElementById('mushroom').innerHTML = numMush;
        resultsEl.innerHTML += '<img src="images/goldmushroom.png">'
        console.log('golden mushroom');

    } else {
        // Get Bullet Bill
        numBill++;
        document.getElementById('bullet').innerHTML = numBill;
        resultsEl.innerHTML += '<img src="images/bulletbill.png">'
        console.log('bullet bill')
    }
}

function runFive() {
    for (let n = 0; n < 5; n++) {
        getItem();
    }
}

function fiveBills() {
    while (numBill < 5) {
        getItem();
    }
}

function tenBills() {
    while (numBill < 10) {
        getItem();
    }
}